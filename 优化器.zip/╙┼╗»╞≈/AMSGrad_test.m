clc; clear;

% 读取数据
train_labels_id = fopen('train-labels.idx1-ubyte', 'r');
test_labels_id = fopen('t10k-labels.idx1-ubyte', 'r');
train_images_id = fopen('train-images.idx3-ubyte', 'r');
test_images_id = fopen('t10k-images.idx3-ubyte', 'r');

fseek(train_labels_id, 8, 'bof');
train_labels = fread(train_labels_id);
fclose(train_labels_id);

fseek(test_labels_id, 8, 'bof');
test_labels = fread(test_labels_id);
fclose(test_labels_id);

fseek(train_images_id, 16, 'bof');
train_images = fread(train_images_id, [784, 60000]);
fclose(train_images_id);
train_images = train_images';

fseek(test_images_id, 16, 'bof');
test_images = fread(test_images_id, [784, 10000]);
fclose(test_images_id);
test_images = test_images';

% 将标签转换为 categorical 类型
train_labels = categorical(train_labels);
test_labels = categorical(test_labels);

% 构建神经网络
layers = [
    featureInputLayer(784, 'Name', 'input', 'Normalization', 'none')  % 输入层
    fullyConnectedLayer(128, 'Name', 'fc1', 'WeightsInitializer', 'narrow-normal')  % 第一全连接层
    reluLayer('Name', 'relu1')               % ReLU 激活函数
    fullyConnectedLayer(64, 'Name', 'fc2', 'WeightsInitializer', 'narrow-normal')   % 第二全连接层
    reluLayer('Name', 'relu2')    
    fullyConnectedLayer(10, 'Name', 'fc3', 'WeightsInitializer', 'narrow-normal')   % 输出层
    softmaxLayer('Name', 'softmax')         % Softmax 激活函数
    classificationLayer('Name', 'output')   % 分类层
];

% 自定义训练选项
options = trainingOptions('adam', ...
    'MaxEpochs', 10, ...       % 最大迭代次数
    'MiniBatchSize', 128, ...  % 批量大小
    'InitialLearnRate', 0.001, ... % 初始学习率
    'LearnRateSchedule', 'piecewise', ... % 分段衰减学习率
    'LearnRateDropPeriod', 5, ... % 每5个epoch下降一次
    'LearnRateDropFactor', 0.5, ... % 学习率下降因子（学习率减半）
    'Shuffle', 'every-epoch', ...
    'ValidationData', {test_images, test_labels}, ...
    'Verbose', true, ...
    'Plots', 'training-progress', ...
    'OutputFcn', @(info) plotMetrics(info)... % 使用 OutputFcn 绘制图形
);

% 训练神经网络
[net, info] = trainNetwork(train_images, train_labels, layers, options);


% 自定义 AMSGrad 更新函数
function [updates, state] = AMSGrad(gradients, state)
    if nargin == 1
        state = struct;
    end

    if ~isfield(state, 'beta1')
        state.beta1 = 0.9;
    end
    if ~isfield(state, 'beta2') 
        state.beta2 = 0.999;
    end
    if ~isfield(state, 'epsilon')
        state.epsilon = 1e-8;
    end
    if ~isfield(state, 'iteration')
        state.iteration = 1;
    end
    if ~isfield(state, 'm')
        state.m = zeros(size(gradients));
    end
    if ~isfield(state, 'v')
        state.v = zeros(size(gradients));
    end
    if ~isfield(state, 'vhat')
        state.vhat = zeros(size(gradients));
    end
    if ~isfield(state, 'alpha')
        state.alpha = 1e-2;
    end

    % 更新偏置一阶矩估计
    state.m = state.beta1 * state.m + (1 - state.beta1) * gradients;
    
    % 更新偏置二阶矩估计
    state.v = state.beta2 * state.v + (1 - state.beta2) * gradients.^2;
    
    % 非递减更新
    state.vhat = max(state.vhat, state.v);
    
    % 更新参数
    updates = state.alpha * state.m ./ (sqrt(state.vhat) + state.epsilon);

    % 更新迭代次数
    state.iteration = state.iteration + 1;
end
