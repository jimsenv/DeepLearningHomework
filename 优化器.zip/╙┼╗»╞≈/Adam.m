clc; clear;

% 读取数据
train_labels_id = fopen('train-labels.idx1-ubyte', 'r');
test_labels_id = fopen('t10k-labels.idx1-ubyte', 'r');
train_images_id = fopen('train-images.idx3-ubyte', 'r');
test_images_id = fopen('t10k-images.idx3-ubyte', 'r');

fseek(train_labels_id, 8, 'bof');
train_labels = fread(train_labels_id);
fclose(train_labels_id);

fseek(test_labels_id, 8, 'bof');
test_labels = fread(test_labels_id);
fclose(test_labels_id);

fseek(train_images_id, 16, 'bof');
train_images = fread(train_images_id, [784, 60000]);
fclose(train_images_id);
train_images = train_images';

fseek(test_images_id, 16, 'bof');
test_images = fread(test_images_id, [784, 10000]);
fclose(test_images_id);
test_images = test_images';

% 将标签转换为 categorical 类型
train_labels = categorical(train_labels);
test_labels = categorical(test_labels);

% 输入数据应该是每个图像展平后的数据，形式是 [样本数, 特征数]
% train_images 和 test_images 已经是大小为 [60000, 784] 和 [10000, 784] 的二维数组

layers = [
    featureInputLayer(784, 'Name', 'input', 'Normalization', 'none')  % 输入层
    fullyConnectedLayer(128, 'Name', 'fc1', 'WeightsInitializer', 'narrow-normal')  % 第一全连接层
    reluLayer('Name', 'relu1')               % ReLU 激活函数
    fullyConnectedLayer(64, 'Name', 'fc2', 'WeightsInitializer', 'narrow-normal')   % 第二全连接层
    reluLayer('Name', 'relu2')    
    fullyConnectedLayer(10, 'Name', 'fc3', 'WeightsInitializer', 'narrow-normal')   % 输出层
    softmaxLayer('Name', 'softmax')         % Softmax 激活函数
    classificationLayer('Name', 'output')   % 分类层
];

% 选择不同的学习率策略
options = trainingOptions('adam', ...
    'MaxEpochs', 10, ...       % 最大迭代次数
    'MiniBatchSize', 128, ...  % 批量大小
    'InitialLearnRate', 0.001, ... % 初始学习率
    'LearnRateSchedule', 'piecewise', ... % 分段衰减学习率
    'LearnRateDropPeriod', 5, ... % 每5个epoch下降一次
    'LearnRateDropFactor', 0.5, ... % 学习率下降因子（学习率减半）
    'Shuffle', 'every-epoch', ...
    'ValidationData', {test_images, test_labels}, ...
    'Verbose', true, ...
    'Plots', 'training-progress',...
    'L2Regularization', 0.01);

% 训练神经网络
[net, info] = trainNetwork(train_images, train_labels, layers, options);
