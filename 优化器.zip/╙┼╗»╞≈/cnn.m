clc; clear;

% 读取数据
train_labels_id = fopen('train-labels.idx1-ubyte', 'r');
test_labels_id = fopen('t10k-labels.idx1-ubyte', 'r');
train_images_id = fopen('train-images.idx3-ubyte', 'r');
test_images_id = fopen('t10k-images.idx3-ubyte', 'r');

fseek(train_labels_id, 8, 'bof');
train_labels = fread(train_labels_id);
fclose(train_labels_id);

fseek(test_labels_id, 8, 'bof');
test_labels = fread(test_labels_id);
fclose(test_labels_id);

fseek(train_images_id, 16, 'bof');
train_images = fread(train_images_id, [784, 60000]);
fclose(train_images_id);
train_images = train_images';

fseek(test_images_id, 16, 'bof');
test_images = fread(test_images_id, [784, 10000]);
fclose(test_images_id);
test_images = test_images';

% LeNet:输入、卷积、池化、卷积、池化、卷积、全连接、输出
% 创建LeNet网络
% 默认使用sigmoid，batchnormalization，maxpooling，根据对应要求可修改网络
layers = [
    imageInputLayer([28 28 1]) % 输入层
    convolution2dLayer(5, 10, 'Padding', 'same') % 卷积层，核大小默认为5，可改；三个卷积层的通道数量默认为[6 16 120]，可改
    batchNormalizationLayer % 批归一化，可选，下同
    sigmoidLayer % 激活层，可选，下同
    maxPooling2dLayer(2, 'Stride', 2) % 池化层，可改，下同

    convolution2dLayer(5, 32, 'Padding', 'same') 
    batchNormalizationLayer
    sigmoidLayer
    maxPooling2dLayer(2, 'Stride', 2)

    convolution2dLayer(5, 256, 'Padding', 'same') 
    batchNormalizationLayer
    sigmoidLayer

    fullyConnectedLayer(84) % 全连接层
    sigmoidLayer
    fullyConnectedLayer(10) % 输出层
    softmaxLayer % softmax层
    classificationLayer]; % 分类层

% 数据准备
trainImages = reshape(train_images', [28, 28, 1, 60000]);
trainLabels = categorical(train_labels);

testImages = reshape(test_images', [28, 28, 1, 10000]);
testLabels = categorical(test_labels);

options = trainingOptions('sgdm', ...
    'MaxEpochs', 10, ...       % 最大迭代次数
    'MiniBatchSize', 128, ...  % 批量大小
    'InitialLearnRate', 0.001, ... % 初始学习率
    'Momentum',0.9,... %动量大小，为0表示普通的sgd
    'LearnRateSchedule', 'piecewise', ... % 分段衰减学习率
    'LearnRateDropPeriod', 5, ... % 每5个epoch下降一次
    'LearnRateDropFactor', 0.5, ... % 学习率下降因子（学习率减半）
    'Shuffle', 'every-epoch', ...
    'ValidationData', {testImages, testLabels}, ...
    'Verbose', true, ...
    'Plots', 'training-progress');

% 训练网络
[net, trainInfo] = trainNetwork(trainImages, trainLabels, layers, options);

