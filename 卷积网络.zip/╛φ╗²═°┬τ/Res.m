clc; clear;

% 读取图片
train_labels_id = fopen('train-labels-idx1-ubyte', 'r');
test_labels_id = fopen('t10k-labels-idx1-ubyte', 'r');
train_images_id = fopen('train-images-idx3-ubyte', 'r');
test_images_id = fopen('t10k-images-idx3-ubyte', 'r');

fseek(train_labels_id, 8, 'bof');
train_labels = fread(train_labels_id);
fclose(train_labels_id);

fseek(test_labels_id, 8, 'bof');
test_labels = fread(test_labels_id);
fclose(test_labels_id);

fseek(train_images_id, 16, 'bof');
train_images = fread(train_images_id, [784, 60000]);
fclose(train_images_id);
train_images = train_images';

fseek(test_images_id, 16, 'bof'); 
test_images = fread(test_images_id, [784, 10000]);
fclose(test_images_id);
test_images = test_images';

% ResNet 网络结构
layers = [
    imageInputLayer([28 28 1]) % 输入层
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv1') % 第一个卷积层
    batchNormalizationLayer('Name', 'bn1') % 批量归一化层
    reluLayer('Name', 'relu1') % ReLU 激活层
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv2') % 第二个卷积层
    batchNormalizationLayer('Name', 'bn2') % 批量归一化层
    additionLayer(2, 'Name', 'add1') % 残差连接
    reluLayer('Name', 'relu2') % ReLU 激活层
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1') % 池化层

    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv3') % 第三个卷积层
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv4') % 第四个卷积层
    batchNormalizationLayer('Name', 'bn4')
    additionLayer(2, 'Name', 'add2') % 残差连接
    reluLayer('Name', 'relu4') % ReLU 激活层
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2') % 池化层

    convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv5') % 第五个卷积层
    batchNormalizationLayer('Name', 'bn5')
    reluLayer('Name', 'relu5')
    convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv6') % 第六个卷积层
    batchNormalizationLayer('Name', 'bn6')
    additionLayer(2, 'Name', 'add3') % 残差连接
    reluLayer('Name', 'relu6')

    fullyConnectedLayer(10, 'Name', 'fc') % 全连接层
    softmaxLayer('Name', 'softmax') % softmax 层
    classificationLayer('Name', 'classoutput')]; % 分类层

% 创建图形并添加连接
lgraph = layerGraph(layers);

% 添加连接
lgraph = connectLayers(lgraph, 'relu1', 'add1/in2'); % 第一个残差连接
lgraph = connectLayers(lgraph, 'relu3', 'add2/in2'); % 第二个残差连接
lgraph = connectLayers(lgraph, 'relu5', 'add3/in2'); % 第三个残差连接

% 数据准备
trainImages = reshape(train_images', [28, 28, 1, 60000]);
trainLabels = categorical(train_labels);

testImages = reshape(test_images', [28, 28, 1, 10000]);
testLabels = categorical(test_labels);

options = trainingOptions('sgdm', ...
    'MaxEpochs', 10, ... % 设置迭代次数
    'Shuffle', 'every-epoch', ...
    'Verbose', false, ...
    'Plots', 'training-progress', ... % 显示训练过程图
    'ValidationData', {testImages, testLabels}, ...
    'ValidationFrequency', 30, ... % 每30个迭代验证一次
    'LearnRateSchedule', 'piecewise', ...
    'InitialLearnRate', 0.01, ...
    'LearnRateDropFactor', 0.1, ...
    'LearnRateDropPeriod', 5);

% 训练网络
[net, trainInfo] = trainNetwork(trainImages, trainLabels, lgraph, options);


% 提取训练信息
trainLoss = trainInfo.TrainingLoss;
valLoss = trainInfo.ValidationLoss;
trainAccuracy = trainInfo.TrainingAccuracy / 100; 
valAccuracy = trainInfo.ValidationAccuracy / 100; 

% 计算误差
trainError = 1 - trainAccuracy; 
valError = 1 - valAccuracy; 

epochs = 1:length(trainLoss); 

% 绘图
figure;
subplot(3, 1, 1);
plot(epochs, trainLoss, 'b-', 'LineWidth', 1.5); hold on;
plot(epochs, valLoss, 'r-', 'LineWidth', 1.5);
xlabel('Epoch');
ylabel('Loss');
title('Loss Function');
legend('Training Loss', 'Validation Loss');
grid on;

subplot(3, 1, 2);
plot(epochs, trainError, 'b-', 'LineWidth', 1.5); hold on;
plot(epochs, valError, 'r-', 'LineWidth', 1.5);
xlabel('Epoch');
ylabel('Error');
title('Training and Validation Error');
legend('Training Error', 'Validation Error');
grid on;

subplot(3, 1, 3);
plot(epochs, trainAccuracy, 'b-', 'LineWidth', 1.5); hold on;
plot(epochs, valAccuracy, 'r-', 'LineWidth', 1.5);
xlabel('Epoch');
ylabel('Accuracy');
title('Training and Validation Accuracy');
legend('Training Accuracy', 'Validation Accuracy');
grid on;

% 调整图形布局
sgtitle('Training and Validation Performance');