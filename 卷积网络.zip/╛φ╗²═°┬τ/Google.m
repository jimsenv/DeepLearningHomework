clc; clear;

% 读取图片
train_labels_id = fopen('train-labels-idx1-ubyte', 'r');
test_labels_id = fopen('t10k-labels-idx1-ubyte', 'r');
train_images_id = fopen('train-images-idx3-ubyte', 'r');
test_images_id = fopen('t10k-images-idx3-ubyte', 'r');

fseek(train_labels_id, 8, 'bof');
train_labels = fread(train_labels_id);
fclose(train_labels_id);

fseek(test_labels_id, 8, 'bof');
test_labels = fread(test_labels_id);
fclose(test_labels_id);

fseek(train_images_id, 16, 'bof');
train_images = fread(train_images_id, [784, 60000]);
fclose(train_images_id);
train_images = train_images';

fseek(test_images_id, 16, 'bof'); 
test_images = fread(test_images_id, [784, 10000]);
fclose(test_images_id);
test_images = test_images';

% GoogleNet网络结构
layers = [
    imageInputLayer([28 28 1]) % 输入层

    % 第一个卷积层
    convolution2dLayer(3, 32, 'Padding', 'same')
    reluLayer

    % 第一个Inception模块，后面有定义函数
    inceptionModule(32, 32, 64, 16, 16)

    % 第二个Inception模块
    inceptionModule(64, 32, 64, 16, 16)

    % 池化层
    averagePooling2dLayer(7, 'Stride', 1)

    fullyConnectedLayer(10) % 全连接层，输出类别为10
    softmaxLayer % softmax 层
    classificationLayer % 分类层
];

% 数据准备
trainImages = reshape(train_images', [28, 28, 1, 60000]);
trainLabels = categorical(train_labels);

testImages = reshape(test_images', [28, 28, 1, 10000]);
testLabels = categorical(test_labels);

options = trainingOptions('sgdm', ...
    'MaxEpochs', 10, ... % 设置迭代次数
    'Shuffle', 'every-epoch', ...
    'Verbose', false, ...
    'Plots', 'training-progress', ... % 显示训练过程图
    'ValidationData', {testImages, testLabels}, ...
    'ValidationFrequency', 30, ... % 每30个迭代验证一次
    'LearnRateSchedule', 'piecewise', ...
    'InitialLearnRate', 0.01, ...
    'LearnRateDropFactor', 0.1, ...
    'LearnRateDropPeriod', 5);

% 训练网络
[net, trainInfo] = trainNetwork(trainImages, trainLabels, layers, options);

% 提取训练信息
trainLoss = trainInfo.TrainingLoss;
valLoss = trainInfo.ValidationLoss;
trainAccuracy = trainInfo.TrainingAccuracy / 100; 
valAccuracy = trainInfo.ValidationAccuracy / 100; 

% 计算误差
trainError = 1 - trainAccuracy; 
valError = 1 - valAccuracy; 

epochs = 1:length(trainLoss); 

% 绘图
figure;
subplot(3, 1, 1);
plot(epochs, trainLoss, 'b-', 'LineWidth', 1.5); hold on;
plot(epochs, valLoss, 'r-', 'LineWidth', 1.5);
xlabel('Epoch');
ylabel('Loss');
title('Loss Function');
legend('Training Loss', 'Validation Loss');
grid on;

subplot(3, 1, 2);
plot(epochs, trainError, 'b-', 'LineWidth', 1.5); hold on;
plot(epochs, valError, 'r-', 'LineWidth', 1.5);
xlabel('Epoch');
ylabel('Error');
title('Training and Validation Error');
legend('Training Error', 'Validation Error');
grid on;

subplot(3, 1, 3);
plot(epochs, trainAccuracy, 'b-', 'LineWidth', 1.5); hold on;
plot(epochs, valAccuracy, 'r-', 'LineWidth', 1.5);
xlabel('Epoch');
ylabel('Accuracy');
title('Training and Validation Accuracy');
legend('Training Accuracy', 'Validation Accuracy');
grid on;

% 调整图形布局
sgtitle('Training and Validation Performance');




% Inception
function layer = inceptionModule(inputChannels1, inputChannels2, inputChannels3, inputChannels4, inputChannels5)
    layer = [
        % 1x1 卷积
        convolution2dLayer(1, inputChannels1, 'Padding', 'same')
        reluLayer

        % 1x1 卷积 + 3x3 卷积
        convolution2dLayer(1, inputChannels2, 'Padding', 'same')
        reluLayer
        convolution2dLayer(3, inputChannels3, 'Padding', 'same')
        reluLayer

        % 1x1 卷积 + 5x5 卷积
        convolution2dLayer(1, inputChannels4, 'Padding', 'same')
        reluLayer
        convolution2dLayer(5, inputChannels5, 'Padding', 'same')
        reluLayer

        % 3x3 最大池化 + 1x1 卷积
        maxPooling2dLayer(3, 'Stride', 1, 'Padding', 'same')
        convolution2dLayer(1, inputChannels1, 'Padding', 'same')
        reluLayer
    ];
end
