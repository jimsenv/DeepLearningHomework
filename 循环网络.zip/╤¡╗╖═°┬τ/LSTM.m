clc; clear;

% Step 1: 加载和预处理文本数据
textData = fileread('time_machine.txt'); 

% Step 2: 处理双引号内的内容
% 在引号内的内容处理为一个整体，并且保留标点
textData = regexprep(textData, '"([^"]*)"', '<<QUOTE_START>>$1<<QUOTE_END>>');  % 替换引号内的内容
textData = lower(textData);  % 这里才统一将文本转小写，之后句子中的首字母需要大写

% Step 3: 按句子拆分文本，优先处理引号外部的内容
sentences = split(textData, {'.', '?', '!', ';', ':'});  % 根据标点拆分句子

% Step 4: 恢复引号内的内容
% 将双引号内的内容重新恢复
sentences = strrep(sentences, '<<QUOTE_START>>', '"');
sentences = strrep(sentences, '<<QUOTE_END>>', '"');

% Step 5: 清理句子，删除无效的句子
sentences = regexprep(sentences, '[^a-z0-9\s''"!?.,;:]', '');  % 清理非字母数字的字符
sentences = strtrim(sentences);  % 删除首尾的空白
sentences = sentences(~cellfun('isempty', sentences));  % 删除空句子

% Step 6: 将每个句子的首字母大写，其他字母小写
sentences = cellfun(@(x) [upper(x(1)), x(2:end)], sentences, 'UniformOutput', false);

% Step 7: 按句子分割为单词
sentenceTokens = cellfun(@(x) split(x), sentences, 'UniformOutput', false);

% Step 8: 构建词汇表
allTokens = vertcat(sentenceTokens{:});  % 将所有句子的单词合并成一个单元格
allTokens = allTokens(~cellfun(@(x) ~isempty(x) && (isstrprop(x(1), 'digit') || isstrprop(x(1), 'punct')), allTokens));  % 去除包含数字或标点的单词

% 清理标点并转换为小写
allTokens = cellfun(@(x) lower(regexprep(x, '[^\w\s]', '')), allTokens, 'UniformOutput', false);

% 定义有效词的函数
% 注意在较低版本的MATLAB中此处会报错，原因是低版本的MATLAB不支持在主函数中定义函数，可以将此函数挪到代码最下端。2024版本则不会报错。后同
function isValid = isValidWord(word)
    % 可以根据需要自定义有效词的判断规则，默认去除数字和单一符号
    isValid = ~isempty(word) && ~any(isstrprop(word, 'digit')) && ~all(isstrprop(word, 'punct'));
end 

% 过滤掉无效的词
validTokens = allTokens(cellfun(@(x) ~isempty(x) && isValidWord(x), allTokens));  
vocab = unique(validTokens);  % 获取词汇表
vocab = [{'unk'}; vocab];  % 将 "unk" 放在词汇表开头，unk代指unknown，对应所有位置词汇和句子的终止符
numWords = numel(vocab);  % 获取词汇表的大小

% 创建单词与索引的映射
word2idx = containers.Map(vocab, 1:numWords); 
idx2word = containers.Map(1:numWords, vocab); 
word2idx('unk') = numWords + 1;  
idx2word(numWords + 1) = 'unk';

% Step 9: 创建输入和目标序列
inputSeq = {};  
targetSeq = {};  
for i = 1:numel(sentenceTokens)
    sentence = sentenceTokens{i};
    if numel(sentence) > 1
        sentenceIdx = cellfun(@(x) getWordIndex(x, word2idx), sentence);
        inputSeq{end+1} = sentenceIdx(1:end-1);
        targetSeq{end+1} = sentenceIdx(2:end);
    end
end

function idx = getWordIndex(word, word2idx)
    if isKey(word2idx, word)
        idx = word2idx(word);
    else
        idx = word2idx('unk'); 
    end
end

% Step 10: 定义 LSTM 模型
embeddingDim = 256;  % 词嵌入维度
numHiddenUnits = 512;  % LSTM隐藏单元数

layers = [ ...
    sequenceInputLayer(1) 
    wordEmbeddingLayer(embeddingDim, 4390)
    lstmLayer(numHiddenUnits, 'OutputMode', 'sequence')
    dropoutLayer(0.2)  
    fullyConnectedLayer(4390)
    softmaxLayer
    classificationLayer];

% Step 11: 设置训练选项
options = trainingOptions('adam', ...
    'MaxEpochs', 100, ...  
    'MiniBatchSize', 128, ... 
    'Verbose', true, ...
    'InitialLearnRate', 0.01, ... % 初始学习率
    'LearnRateSchedule', 'piecewise', ... % 分段衰减学习率，防止梯度爆炸
    'LearnRateDropPeriod', 2, ... 
    'LearnRateDropFactor', 0.9, ... % 学习率下降因子
    'GradientThreshold', 5, ...  % 限制梯度，同样防止梯度爆炸
    'Plots', 'training-progress'); 

% Step 12: 准备数据并训练模型
X = cellfun(@(x) reshape(x, [1, numel(x), 1]), inputSeq, 'UniformOutput', false);
Y = cellfun(@(x) (x(:)'), targetSeq, 'UniformOutput', false);

% 在实际运行代码时发现，部分词汇表中的词汇并没有在Y中出现，故删除这些未出现的词汇
doko=zeros(1,4808);
for p = 1:2066
    t = Y{p};
    for q = 1:length(t)
        if t(q) == 4809  
        % 这里在实际运行中报错，究其原因是Y中的分类并没有把unk放在第一位而是4809位
            doko(1) = 1;
        else
            doko(t(q)) = 1;
        end
    end
end

zeroIndices = find(doko == 0);
vocab(zeroIndices) = [];  

Y = cellfun(@categorical, Y, 'UniformOutput', false);

net = trainNetwork(X, Y, layers, options);

% step 13: 定义句子生成函数
function generatedText = generateSentence(net, startWord, word2idx, idx2word, maxLength, temperature)

    currentWord = startWord;  
    generatedText = startWord;  
    generatedHistory = {};  % 用来存储已生成的单词，以避免过度依赖某些单词

    for i = 1:maxLength
        if isKey(word2idx, currentWord)
            wordIdx = word2idx(currentWord);
        else
            wordIdx = word2idx('unk');  % 默认词汇
        end
        
        % 通过softmax函数计算每个单词的概率
        scores = predict(net, wordIdx');  
        scores = exp(scores / temperature) / sum(exp(scores / temperature));  % 调整温度

        % 为已生成的单词增加惩罚
        for j = 1:length(generatedHistory)
            prevWord = generatedHistory{j};
            
            % 检查单词是否在词汇表中
            if isKey(word2idx, prevWord)
                prevWordIdx = word2idx(prevWord);
                
                % 确保 prevWordIdx 在有效范围内
                if prevWordIdx >= 1 && prevWordIdx <= length(scores)
                    scores(prevWordIdx) = scores(prevWordIdx) * 0.5;  % 对已生成的单词惩罚，降低其概率
                end
            end
        end

        % 进行 Top-k 采样（例如取前50个概率最高的词汇）
        k = 50;  % 设定Top-k的大小
        [~, sortedIdx] = sort(scores, 'descend');
        topKIdx = sortedIdx(1:k);
        topKScores = scores(topKIdx);
        topKScores = topKScores / sum(topKScores);  % 归一化概率分布
        
        % 从前k个词汇中采样
        sampledIdx = randsample(topKIdx, 1, true, topKScores);

        % 使用整数索引来获取单词
        nextWord = idx2word(sampledIdx);

        % 将生成的单词加入历史记录
        generatedHistory{end + 1} = nextWord;

        % 将生成的单词添加到文本中
        generatedText = strcat(generatedText, " ", nextWord);
        currentWord = nextWord;

        % 限制最大生成长度，并优化停止条件
        if i >= maxLength || any(strcmp(nextWord, {'.', '!', '?'}))
            break;
        end
    end
end

% Step 14: 测试句子生成
prompts = ["time traveller", "traveller", "the time traveller says that", ...
           "when the time traveller returns to the garden", ...
           "the time traveller begins learning the language", ...
           "the time traveller determines that", ...
           "the time traveller knows he will have to stop", ...
           "when he wakes up", ...
           "the time traveller finds himself", ...
           "the time traveller tells the narrator to wait for him"];

for i = 1:numel(prompts)
    prompt = prompts(i);
    fprintf("Prompt: %s\n", prompt);
    
    generatedText = generateSentence(net, prompt, word2idx, idx2word, 50, 0.9);
    generatedWords = strsplit(generatedText);  

    text='';
    for j=1:length(generatedWords)
        if generatedWords(j)~='unk'
            text=text+generatedWords(j)+' ';
        else
            break;% 若为unk则停止输出（即将unk当做终止符）
        end
    end

    fprintf("Generated: %s\n\n", text);
end