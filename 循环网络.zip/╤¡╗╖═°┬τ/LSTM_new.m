function generatedText = generateSentence(net, startWord, word2idx, idx2word, maxLength, temperature)

    currentWord = startWord;  
    generatedText = startWord;  
    generatedHistory = {};  
    wordCount = 0;  % 计数器，用于追踪已经生成的单词数量

    for i = 1:maxLength
        % 获取当前单词的索引
        if isKey(word2idx, currentWord)
            wordIdx = word2idx(currentWord);
        else
            wordIdx = word2idx('unk');  
        end
        
        % 预测下一个单词的概率
        scores = predict(net, wordIdx');  
        scores = exp(scores / temperature) / sum(exp(scores / temperature));  

        % 每10个预测时，不允许预测 'unk'
        if wordCount < 10
            unkIdx = word2idx('unk');
            scores(unkIdx) = 0;  % 确保前10个预测时不预测 'unk'
        else
            % 每10个预测时，将 'unk' 的得分翻倍
            if wordCount >= 10
                scores(unkIdx) = scores(unkIdx) * exp(wordCount*0.2);  
            end
        end

        % 降低其他历史单词的概率（避免重复）
        for j = 1:length(generatedHistory)
            prevWord = generatedHistory{j};
            if isKey(word2idx, prevWord)
                prevWordIdx = word2idx(prevWord);
                if prevWordIdx >= 1 && prevWordIdx <= length(scores)
                    scores(prevWordIdx) = scores(prevWordIdx) * 0.5;  % 对历史单词惩罚
                end
            end
        end

        % 采样 Top-k 单词
        k = 20;  % 降低k值，避免采样空间过大
        [~, sortedIdx] = sort(scores, 'descend');
        topKIdx = sortedIdx(1:k);
        topKScores = scores(topKIdx);
        topKScores = topKScores / sum(topKScores);  % 归一化

        % 采样单词
        sampledIdx = randsample(topKIdx, 1, true, topKScores);

        nextWord = idx2word(sampledIdx);

        % 确保不会预测到 'unk'，如果预测到了 'unk'，就跳过
        if strcmp(nextWord, 'unk') && wordCount>10
            break;  % 跳过 'unk' 预测，继续下一个
        end

        generatedHistory{end + 1} = nextWord;
        generatedText = strcat(generatedText, " ", nextWord);
        currentWord = nextWord;

        % 增加单词计数
        wordCount = wordCount + 1;

        % 限制生成句子的最大长度，或遇到句号、问号、感叹号时停止
        if i >= maxLength || any(strcmp(nextWord, {'.', '!', '?'}))
            break;
        end
    end
end

prompts = ["time traveller", "traveller", "the time traveller says that", ...
           "when the time traveller returns to the garden", ...
           "the time traveller begins learning the language", ...
           "the time traveller determines that", ...
           "the time traveller knows he will have to stop", ...
           "when he wakes up", ...
           "the time traveller finds himself", ...
           "the time traveller tells the narrator to wait for him"];

for i = 1:numel(prompts)
    prompt = prompts(i);
    fprintf("Prompt: %s\n", prompt);
    
    generatedText = generateSentence(net, prompt, word2idx, idx2word, 50, 0.5); % 降低温度以降低随机性
    generatedWords = strsplit(generatedText);  

    text=''; 
    for j=1:length(generatedWords)
        if generatedWords(j)~='unk'
            text=text+generatedWords(j)+' ';
        else
            break; 
        end
    end

    fprintf("Generated: %s\n\n", text);
end